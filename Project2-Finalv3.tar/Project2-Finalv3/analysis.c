#include <math.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
//#include "strbuf.c"
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

typedef struct comp_result {
    char *file1, *file2;
    unsigned totalwords;     // word count of file 1 + file 2
    double JSD;     // JSD between file 1 and file 2
}comp_result;

/* void freeArray(comp_result* results, int comparisons){
	int k;
	for(k = 0; k < comparisons; k++){
		free(results[k].file1);
		free(results[k].file2);
		free(results[k]);
	}
	free(results);
} */


/* comp_result Create(char* f1, char* f2, unsigned total, double JSD)
{
	struct comp_result* res = (struct comp_result*)malloc(sizeof(struct comp_result));
	res->file1 = f1;
	res->file2 = f2;
	res->totalwords = total;
	res->JSD = JSD;
	return res[0];
} */

wordnode* CloneFile1(wordnode* f1) {
    if (f1 == NULL) 
    	return NULL;

    wordnode* result = createNode(f1->word);
    result->numoccur = f1->numoccur;
    result->next = CloneFile1(f1->next);
    return result;
}

double totalcomputation(wordnode* file1, wordnode* file2, wordnode* file)
{
  //printf("In total computation\n");
	double KLD1 = 0, KLD2 = 0, JSD = 0;
	wordnode* prev;
	wordnode* ptr = file;
	wordnode* pf1 = file1, *pf2 = file2;
	wordnode* head1 = file1, *head2 = file2;
	/* while(ptr!= NULL){
	  printf("Ptr1 Word in total file: %s\n", ptr->word);
	  ptr = ptr->next;
	} */
	prev = file;
	//ptr = file;
	while(ptr != NULL)
	{
	  //printf("Word in totalfile: %s\n", ptr->word);
		while(strcmp(pf1->word, ptr->word) != 0)
			ptr = ptr->next;
		//printf("****************************\n");
		//printf("Total Words in File: %f Word: %s Frequency: %d Mean Word Frequency: %f\n",pf1->WFD,pf1->word,pf1->numoccur,ptr->WFD);
		KLD1 += (pf1->WFD*log2((pf1->WFD)/(ptr->WFD))); // need to fix how we get mean WFD
		//printf("KLD1 IS %f\n",KLD1);
		//printf("****************************\n");
		ptr = ptr->next;
		//printf("After moving pointer*%s\n", ptr->word);
		if(pf1->next != NULL)
		  pf1 = pf1->next;
		else
		  break;
		
	}
	file = prev;
	wordnode* ptr2 = file;
	/* while(ptr2 !=NULL){
	  printf("&Ptr2: %s\n", ptr2->word);
	  ptr2 = ptr2->next;
	}
	ptr2 = file;
	printf("After while1****\n"); */
	while(ptr2 != NULL)
	{
	  //printf("Inside the while\n");
	  while(strcmp(pf2->word, ptr2->word) != 0)
	    {
	      //printf("In ptr2 while loop\n");
		  ptr2 = ptr2->next;
	    }
		//printf("****************************\n");
		//printf("Total Words in File: %f Word: %s Frequency: %d Mean Word Frequency: %f\n",pf2->WFD,pf2->word,pf2->numoccur,ptr2->WFD);
		KLD2 += (pf2->WFD*log2((pf2->WFD)/(ptr2->WFD))); // need to fix how we get mean WFD
		//printf("KLD2 IS %f\n",KLD2);
		//printf("****************************\n");
		ptr2 = ptr2->next;
		if(pf2->next != NULL)
		  pf2 = pf2->next;
		else
		  break;
	}
	JSD = sqrt((0.5*KLD1)+(0.5*KLD2));
	file1 = head1;
	file2 = head2;
	//printf("TOTAL COMPUTATION RESULT IS %f\n",JSD);
	//RETURN JSD WHEN KLD IS FIXED TODO!!!!!
	return JSD;
}

double  createCombined(wordnode* f1, wordnode* f2)
{
  //printf("The word count for file 1 here is %d\n",f1->totalnodes);
	//printf("The word count for file 2 here is %d\n",f2->totalnodes);
	if(f1 == NULL || f2 == NULL)
	{
		if(f1 == NULL && f2 == NULL)
			return 0;
		else{
			return sqrt(0.5);
		}
	}
	wordnode* fhead = NULL;
	wordnode* ptr1;
	wordnode* ptr2;
	wordnode* fptr = NULL;
	wordnode* prev = NULL;

	/* if(f2 != NULL){
		ptr2 = f2;
	} */
	ptr1 = f1;
        /* ptr2 = f2;
        printf("1File1 is: %s File2 is: %s\n", f1->word, f2->word);
        while(ptr1 != NULL){
          printf("f1 -> %s\n", ptr1->word);
          ptr1 = ptr1->next;
        }
        while(ptr2 != NULL){
          printf("f2 -> %s\n", ptr2->word);
          ptr2 = ptr2->next;
        }
	printf("*****************\n"); */
	ptr2 = f2;

	if(f1->next == NULL){
	  fhead = createNode(f1->word);
	  fhead->numoccur = f1->numoccur;
	  fhead->totalnodes = f1->totalnodes + f2->totalnodes;
	}
	
	//printf("CREATING NODE WITH HEAD AS %s\n",f1->word);
	//fhead = createNode(f1->word);
	//printf("FINISHED CREATING NODE WITH HEAD AS %s\n",fhead->word);
	//fhead->numoccur = f1->numoccur;
	//printf("The total words for f1 here is %d\n",f1->totalnodes);
	//printf("The total words for f2 here is %d\n",f2->totalnodes);
	//fhead->totalnodes = f1->totalnodes + f2->totalnodes;
	//printf("COMBINED TOTAL OF WORDS IS %d\n", fhead->totalnodes);
	
	else{
	  fhead = CloneFile1(f1);
	  /*printf("In file 1 loop\n");
	  ptr1 = f1;
		fptr = fhead;
		while(ptr1 != NULL)
		{
		  if(prev == NULL){
		    fptr = createNode(ptr1->word);
		    fptr->numoccur = ptr1->numoccur;
		    prev = fptr;
		  }
		  else
		    {
		      fptr->next = createNode(ptr1->word);
		      fptr->next->numoccur = ptr1->numoccur;
		    }
			printf("ptr1: %s fptr: %s numoccurence = %d ptr1 numoccurence = %d\n", ptr1->word, fptr->word, fptr->numoccur, ptr1->numoccur);
			fptr = fptr->next;
			ptr1 = ptr1->next;
		}
		printf("After the file1loop\n");
		printf("Prev = %s\n", prev->word);
		//fptr->next = NULL;
		printf("After making fptr->next null\n");*/
	}
	/* prev = fhead;
	while(fhead != NULL)
	  {
	    printf("Fhead: %s\n", fhead->word);
	    fhead = fhead->next;
	  }
	fhead = prev;
	printf("Total nodes of fhead: %d\n", fhead->totalnodes);
	printf("Before total nodes\n"); */
	fhead->totalnodes = f1->totalnodes + f2->totalnodes;
	//printf("After total nodes\n");

	prev = fptr;
	fptr = fhead;
	//printf("Before creating full file\n");
	while(ptr2 != NULL)
	{
	  //printf("In create combined while\n");
		if(strcmp(fptr->word, ptr2->word) == 0)
		{
			fptr->numoccur += ptr2->numoccur;
			ptr2 = ptr2->next;
			if(fptr->next != NULL)
			{	
				prev = fptr;
				fptr = fptr->next;
			}
			else
			{
				break;
			}
		}
		else if(strcmp(fptr->word, ptr2->word) < 0)
		{
			if(fptr->next != NULL)
			{
				prev = fptr;
				fptr = fptr->next;
			}
			else
				break;
		}
		else
		{
			wordnode* thenode = createNode(ptr2->word);
			thenode->numoccur = ptr2->numoccur;
			thenode->next = fptr;
			if(fptr == fhead)
			{
				thenode->totalnodes = fhead->totalnodes;
				fhead = thenode;
			}
			else
			prev->next = thenode;
			fptr = thenode;
			ptr2 = ptr2->next;
		}
	}
	if(ptr2 != NULL)
	{
	  fptr->next = CloneFile1(ptr2);
	  /*while(ptr2 != NULL)
		{
			fptr->next = ptr2;
			fptr = fptr->next;
			ptr2 = ptr2->next;
		}*/
	}
	
	fptr = fhead;
	ptr1 = f1;
	ptr2 = f2;
	//printf("1File1 is: %s File2 is: %s\n", f1->word, f2->word);
	/* while(ptr1 != NULL){
	  printf("f1 -> %s\n", ptr1->word);
	  ptr1 = ptr1->next;
	}
	while(ptr2 != NULL){
          printf("f2 -> %s\n", ptr2->word);
          ptr2 = ptr2->next;
	}
	ptr1 = f1;
	ptr2 = f2; */
	int x = 0;
	while(fptr != NULL)
	{
	  //printf("[%d] FPTR WORD is: %s PTR1 Word is: %s PTR2 Word is: %s*\n",x,fptr->word,ptr1->word,ptr2->word);
	  if(ptr1 == NULL || ptr2 == NULL)
	    {
	      if(ptr1 == NULL && ptr2 == NULL)
		break;
	      else if(ptr1 == NULL)
		{
		  while(ptr2 != NULL && fptr != NULL)
		    {
		      fptr->WFD = (ptr2->WFD)/2;
		      fptr = fptr->next;
		      ptr2 = ptr2->next;
		    }
		  break;
		}
	      else
		{
		  while(ptr1 != NULL && fptr != NULL)
                    {
                      fptr->WFD	= (ptr1->WFD)/2;
                      fptr = fptr->next;
                      ptr1 = ptr1->next;
                    }
		  break;
		}
	    }
	  //printf("Word is: %s\n", fptr->word);
		if(strcmp(fptr->word, ptr1->word) == 0 && strcmp(fptr->word, ptr2->word) == 0)
		{
			fptr->WFD = (ptr1->WFD + ptr2->WFD)/2;
			fptr = fptr->next;
			ptr1 = ptr1->next;
			ptr2 = ptr2->next;
		}
		else if(strcmp(fptr->word, ptr1->word) == 0 || strcmp(fptr->word, ptr2->word) == 0)
		{
			if(strcmp(fptr->word, ptr1->word) == 0 && strcmp(fptr->word, ptr2->word) > 0)
			{
				ptr2 = ptr2->next;
			}
			else if(strcmp(fptr->word, ptr1->word) == 0 && strcmp(fptr->word, ptr2->word) < 0)
			{
				fptr->WFD = (ptr1->WFD)/2;
				fptr = fptr->next;
				ptr1 = ptr1->next;
			}
			else if(strcmp(fptr->word, ptr1->word) > 0 && strcmp(fptr->word, ptr2->word) == 0)
			{
				ptr1 = ptr1->next;
			}
			else
			{
				fptr->WFD = (ptr2->WFD)/2;
				fptr = fptr->next;
				ptr2 = ptr2->next;
			}
		}
		else
		{
			if(strcmp(fptr->word, ptr1->word) > 0)
				ptr1 = ptr1->next;
			if(strcmp(fptr->word, ptr2->word) > 0)
				ptr2 = ptr2->next;
		}
		//fptr->WFD = (double)fptr->WFD/(double)fhead->totalnodes; // this is not the correct MEAN WFD formula
		//printf("total words is %d\n",fhead->totalnodes);
		//fptr = fptr->next;
		x++;
	}
	//printf("After while loop and before total computation\n");
	double result = totalcomputation(f1, f2, fhead);
	freeWordNodes(fhead);
	return result;
}

int addToArray(int id, comp_result* add, filenode* file1, filenode* file2)
{
  //printf("this is file1 name in addtoarray %s\n", add[0].file1);
  //printf("this is file2 name in addtoarray %s\n", add[0].file2);
    //printf("in addto Array method printing before JSD %d\n",file1->head->totalnodes);
  //printf("File1 = %s File2 = %s\n", file1->filename, file2->filename);
  /*wordnode* f1 = file1->head, *f2 = file2->head;
  while(f1 != NULL)
    {
      printf("fil1: %s\n", f1->word);
      f1 = f1->next;
    }
  while(f2 != NULL)
    {
      printf("fil2: %s\n", f2->word);
      f2 = f2->next;
    }*/
  double JSD = createCombined(file1->head, file2->head);
	//	printf("BEFORE assign total\n");
	unsigned total = file1->totalnodes + file2->totalnodes;
	//printf("AFTER assign total\n");
	//printf("@@this is file1: %s and file2: %s\n", file1->filename, file2->filename);
	//printf("what is id %d\n",id);
	add[id].file1 = file1->filename;
	add[id].file2 = file2->filename;
	add[id].totalwords = total;
	add[id].JSD = JSD;
	//add[id] = Create(file1->filename, file2->filename, total, JSD);
	/* printf("THE JSD IS %f, THE FIRST FILENAME IS %s THE SECOND FILENAME IS %s\n",JSD,file1->filename,file2->filename);
	printf("AFTER CREATING COMP RESULT\n"); */
	return 0;
}
